public class SearchEngineTests {
    public static final String NAMES = "Kristofer Galley\n" +
        "Fernando Marbury fernando_marbury@gmail.com\n" +
        "Kristyn Nix nix-kris@gmail.com\n" +
        "Regenia Enderle\n" +
        "Malena Gray\n" +
        "Colette Mattei\n" +
        "Wendolyn Mcphillips\n" +
        "Jim Gray\n" +
        "Coreen Beckham\n" +
        "Bob Yeh bobyeah@gmail.com\n" +
        "Shannan Bob stropeshah@gmail.com\n" +
        "Yer Fillion\n" +
        "Margene Resendez marres@gmail.com\n" +
        "Blossom Ambler\n" +
        "Teri Ledet teri_ledet@gmail.com\n" +
        "Dana Baron baron@gmail.com\n" +
        "Abram Goldsberry\n" +
        "Yer Leopold\n" +
        "Stefania Trunzo\n" +
        "Alexis Leopold\n" +
        "Carlene Bob\n" +
        "Oliver Dacruz\n" +
        "Jonie Richter\n" +
        "Pasquale Gallien gallien@evilcorp.com\n" +
        "Verdie Gentle\n" +
        "Gerardo Strouth gallien@evilcorp.com\n" +
        "Agripina Bob\n" +
        "Latricia Niebuhr\n" +
        "Malena Schommer\n" +
        "Drema Leopold\n" +
        "Heide Payeur\n" +
        "Ranae Digiovanni\n" +
        "Simona Pereira\n" +
        "Nick Digiovanni\n" +
        "Angelita Wigington gallien@evilcorp.com\n" +
        "Elin Gray\n" +
        "Dwain Trunzo\n" +
        "Boris Beiler\n" +
        "Remi Malek fsociefy@gmail.com\n" +
        "Demetria Hostetler gallien@evilcorp.com\n" +
        "Nydia Mcduffie\n" +
        "Florencio Defibaugh\n" +
        "Warner Giblin\n" +
        "Bob Mans\n" +
        "Shu Gray\n" +
        "Kaycee Gray\n" +
        "Victorina Froehlich victory@gmail.com\n" +
        "Roseanne Gray\n" +
        "Erica Radford hisam@gmail.com\n" +
        "Elyse Pauling";
}
