package search.logic;

import java.io.File;
import java.util.*;

public final class SearchEngine {
    public static Map<String, String> dataMap;
    public static Map<String, ArrayList<String>> invertedIndexMap;

    public static void initDataMap(String fileName) {
        dataMap = new HashMap<>();

        File file = new File(fileName);
        int count = 0;
        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                dataMap.put( count++ + "", fileScanner.nextLine());
            }

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        initInvertedIndexMap(dataMap);
    }
    public static void initInvertedIndexMap(Map<String, String> map) {
        invertedIndexMap = new HashMap<>();

        for (var entry: map.entrySet()) {
            String[] words = entry.getValue().split(" ");
            for (String word: words) {
                String lowWord = word.toLowerCase();
                invertedIndexMap.putIfAbsent(lowWord, new ArrayList<>());
                invertedIndexMap.get(lowWord).add(entry.getKey());
            }
        }
        //System.out.println(invertedIndexMap);
    }

    public static void printDataset() {
        for (String line: dataMap.values()) {
            System.out.println(line);
        }
    }

//    public static void searchInLine(String attribute) {
//        boolean matchFound = false;
//
//        List<String> indices = invertedIndexMap.get(attribute.toLowerCase());
//        if (indices != null) {
//           // System.out.println(indices.size()  + " persons found:");
//            for (String index: indices) {
//                matchFound = true;
//                System.out.println(dataMap.get(index));
//
//            }
//        }
//        if (!matchFound) {
//            System.out.println("No matching people found.");
//        }
//    }
}