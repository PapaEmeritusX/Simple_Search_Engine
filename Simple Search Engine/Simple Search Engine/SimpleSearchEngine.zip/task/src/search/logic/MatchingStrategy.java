package search.logic;

import java.util.SortedSet;

public interface MatchingStrategy {

    void getResult(String[] query);
    void print();
}
